package com.akademicu.albums.dto;

public record AlbumDto(String name, int releaseYear, int nrOfCopies, String band, String genres) {

}

package com.akademicu.albums.exception;

public class AlbumNotFoundExceptionClass extends RuntimeException{
    public AlbumNotFoundExceptionClass(String message) {
        super(message);
    }
}
